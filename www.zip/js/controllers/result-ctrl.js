angular.module('app.resultController', [])

.controller('resultCtrl', ['$scope', '$state', '$rootScope', 'ResultFacotry', '$stateParams',// The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $state, $rootScope, ResultFacotry, $stateParams) {

    console.log($stateParams.subCatName);
    
    $scope.results = ResultFacotry.getResult;
    console.log($scope.results);

}])